﻿using Project.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Controllers
{
    public class AccountsController : Controller
    {
        UserManager<IdentityUser> _userManager = null;
        SignInManager<IdentityUser> _signInManager = null;
        private LaptopDBContext _context;
        public AccountsController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser>signInManager,LaptopDBContext context)
        {
            this._userManager = userManager;
            this._signInManager = signInManager;
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(RegisterViewModel model)
        {
            //ViewBag.msg = "Registered Successfully!!";
            var user = new UserModel
            {
                Email = model.Email,
                Password = model.Password,
                RoleType = model.RoleType
            };
            _context.Add(user);
            _context.SaveChanges();
            return RedirectToAction("Login");
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            //ViewBag.msg = "Login Successfully!!";
            var user = _context.Users.Single(x => x.Email == model.Email);
            if(user.RoleType == "Seller" && user.Password == model.Password)
            {
                return RedirectToAction("index", "seller",new {Id = user.Id });
            }
            else if(user.RoleType =="Customer" && user.Password == model.Password)
            {
                return RedirectToAction("index", "customer");
            }
            else if(model.Email == "admin@admin.com" && model.Password == "admin")
            {
                return RedirectToAction("index", "laptops");
            }
            return RedirectToAction("Login");
        }
    }
}
